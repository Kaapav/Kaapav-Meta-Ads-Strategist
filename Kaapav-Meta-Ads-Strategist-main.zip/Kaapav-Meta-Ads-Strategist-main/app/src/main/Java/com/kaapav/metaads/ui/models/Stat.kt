package com.kaapav.metaads.ui.models

data class Stat(val title: String, val value: String, val change: String)
