package com.kaapav.metaads.ui.models

data class Creative(val title: String, val meta: String, val roas: String, val stats: String, val imageUrl: String)
